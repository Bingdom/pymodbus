"""Helper for commandline etc.

Contains common functions get get_command_line() to avoid duplicating
code that are not relevant for the code as such, like e.g.
get_command_line
"""

from __future__ import annotations

import argparse
import logging
import os
import ssl
from typing import Any

from pymodbus import pymodbus_apply_logging_config


_logger = logging.getLogger(__file__)


def get_commandline(
    server: bool = False,
    description: str | None = None,
    extras: Any = None,
    cmdline: list[str] | None = None,
):
    """Read and check command line arguments."""
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument(
        "-c",
        "--comm",
        choices=["tcp", "udp", "serial", "tls", "unknown"],
        help="set communication, default is tcp",
        dest="comm",
        default="tcp",
        type=str,
    )
    parser.add_argument(
        "-f",
        "--framer",
        choices=["ascii", "rtu", "socket", "tls"],
        help="set framer, default depends on --comm",
        dest="framer",
        type=str,
    )
    parser.add_argument(
        "-l",
        "--log",
        choices=["critical", "error", "warning", "info", "debug"],
        help="set log level, default is info",
        dest="log",
        default="info",
        type=str,
    )
    parser.add_argument(
        "-p",
        "--port",
        help="set port",
        dest="port",
        type=str,
    )
    parser.add_argument(
        "--baudrate",
        help="set serial device baud rate",
        default=9600,
        type=int,
    )
    parser.add_argument(
        "--host",
        help="set host, default is 127.0.0.1",
        dest="host",
        default=None,
        type=str,
    )
    if server:
        parser.add_argument(
            "--device_ids",
            help="set number of device_ids, default is 0 (any)",
            default=0,
            type=int,
        )
        parser.add_argument(
            "--context",
            help="ADVANCED USAGE: set datastore context object",
            default=None,
        )
    else:
        parser.add_argument(
            "--timeout",
            help="ADVANCED USAGE: set client timeout",
            default=10,
            type=float,
        )
    if extras:  # pragma: no cover
        for extra in extras:
            parser.add_argument(extra[0], **extra[1])
    args = parser.parse_args(cmdline)

    # set defaults
    comm_defaults: dict[str, list[int | str]] = {
        "tcp": ["socket", 5020],
        "udp": ["socket", 5020],
        "serial": ["rtu", "/dev/ptyp0"],
        "tls": ["tls", 5020],
    }
    pymodbus_apply_logging_config(args.log.upper())
    logging.basicConfig(level=args.log.upper())
    _logger.setLevel(args.log.upper())
    if not args.framer:
        args.framer = comm_defaults[args.comm][0]
    args.port = args.port or comm_defaults[args.comm][1]
    if args.comm != "serial" and args.port:
        args.port = int(args.port)
    if not args.host:
        args.host = "" if server else "127.0.0.1"
    return args


def get_certificate(suffix: str):
    """Get example certificate."""
    delimiter = "\\" if os.name == "nt" else "/"
    cwd = os.getcwd().split(delimiter)[-1]
    if cwd == "examples":  # pragma: no cover
        path = "."
    elif cwd == "sub_examples":  # pragma: no cover
        path = "../../examples"
    elif cwd == "test":  # pragma: no cover
        path = "../examples"
    elif cwd == "pymodbus":  # pragma: no cover
        path = "examples"
    else:
        raise RuntimeError(f"**Error** Cannot find certificate path={cwd}")
    return f"{path}/certificates/pymodbus_tls.{suffix}"


def generate_ssl(
    is_server: bool,
    certfile: str,
    keyfile: str | None = None,
    password: str | None = None,
) -> ssl.SSLContext:
    """Generate sslctx from cert/key/password.

    MODBUS/TCP Security Protocol Specification demands TLSv2 at least
    """
    new_sslctx = ssl.SSLContext(
        ssl.PROTOCOL_TLS_SERVER if is_server else ssl.PROTOCOL_TLS_CLIENT
    )
    new_sslctx.check_hostname = False
    new_sslctx.verify_mode = ssl.CERT_NONE
    new_sslctx.minimum_version = ssl.TLSVersion.TLSv1_2
    new_sslctx.maximum_version = ssl.TLSVersion.TLSv1_3
    new_sslctx.load_cert_chain(certfile=certfile, keyfile=keyfile, password=password)
    return new_sslctx
